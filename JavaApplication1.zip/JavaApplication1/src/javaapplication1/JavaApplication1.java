/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import java.sql.Connection;
import java.util.Scanner;

/**
 *
 * @author 31782299
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            Class.forName("org.apache.jdbc.ClientDriver");
            out.println("Driver JDBC carregado!");
            
            String url = "jdbc:derby://localhost:1527/faculdade";
            String usuario = "app";
            String senha = "app";
            
            Connection conexao = DriverManager.getConnection(url,usuario,senha);
            out.println("Conexão estabelecida com sucesso!");
            
            String sqlInsert = "INSERT INTO professores(nome, matricula, area");
            sqlInsert += "VALUES (?,?,?)";
            String sqlSelect = "SELECT * FROM professores";
            String sqlUpdate = "UPDATE professores SET nome=?, matricula=?, area=?";
            sqlUpdate += "WHERE id=?";
            String sqlDelete = "DELETE FROM professores WHERE id=?";
            
            PreparedStatement stmInsert = conexao.preparedStatement(sqlInsert);
            PreparedStatement stmSelect = conexao.preparedStatement(sqlSelect);
            PreparedStatement stmUpdate = conexao.preparedStatement(sqlUpdate);
            PreparedStatement stmDelete = conexao.preparedStatement(sqlDelete);
            
            boolean querSair = false;
            Scanner sc = new Scanner(System.in);
            
            while (!querSair) {
                out.println("\menu:");
                out.println("(1) Criar registro");
                out.println("(2) Ler registro");
                out.println("(3) Atualizar registro");
                out.println("(4) Apagar registro");
                out.println("(5) Sair");
                out.println("Opção escolhida: ");
                int opcao = Integer.parseInt(sc.nextLine());
                if (opcao == 1) {
                    out.print("Nome do novo arquivo: ");
                    String nome = sc.nextLine();
                    out.print("Número de matricula do novo registro: ");
                    int matricula = Integer.parseInt(sc.nextLine());
                    out.print("área do novo registro: ");
                    String area = sc.nextLine();
                    
                    stmInsert.setString(1,nome);
                    stmInsert.setString(2,matricula);
                    stmInsert.setString(3,area);
                    int retorno = stmInsert.executeUpdate();
                    out.println("Registros inseridos: "+ retorno);
                }else if(opcao == 2){
                    ResultSet = rs = stmSelect.executeQuery();
                    out.print("Professores: ");
                    while (rs.next()){
                        Long id = rs.getString("ID");
                        String nome = rs.getString("Nome");
                        int matricula = rs.getInt("Matricula");
                        String area = rs.getString("Area");
                        out.println(id + " -" + nome + " - " + matricula + " - " + area);
                        
                        
                    }
                    rs.close();
                }else if(opcao == 3){
                    out.print("ID do registro a ser atualizado: ");
                    long id = Long.parseLong(sc.nextLine());
                    out.print("novo nome: ");
                    String nome = sc.nextLine();
                    out.print("Novo número de matricula");
                    int matricula = Integer.parseInt(sc.nextLine());
                    out.print("Nova área");
                    String area = sc.nextLine();
                    
                    stmUpdate.setString(1,nome);
                    stmUpdate.setString(2,matricula);
                    stmUpdate.setString(3,area);
                    stmUpdate.setString(4,id);
                    int retorno = stmUpdate.executeUpdate();
                    out.println("Registros atualizados: "+retorno);
                } else if (opcao == 4){
                    out.print("id do registro a ser apagado:");
                    long id = Long.parseLong(sc.nextLine());
                    
                    
                } else if (opcao == 5){
                    querSair = true;
                    
                } else {
                    out.println("INVALID");
                }
            
            }
            conexao.close();
        } catch(ClassNotFoundException ex){
            ex.printStackTrace();
            out.println("Driver not found");
        } catch (SQLException ex){
            ex.
              
                
            }
            
        }
    }
    
}
