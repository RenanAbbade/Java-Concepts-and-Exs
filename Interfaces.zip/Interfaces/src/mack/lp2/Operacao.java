/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mack.lp2;

import java.util.Objects;

/**
 *
 * @author 31782299
 */
public class Operacao extends ControleRemoto{
    private int id;
    private String descricao;

    Operacao(String _Ligar_) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        return "Operacao{" + "id=" + id + ", descricao=" + descricao + '}';
    }

    

    @Override
    public boolean equals(Object obj) {
   
        final Operacao other = (Operacao) obj;
        if (this.id != other.id) {
            return false;
        }
        if (!Objects.equals(this.descricao, other.descricao)) {
            return false;
        }
        return true;
        
        
    }

}