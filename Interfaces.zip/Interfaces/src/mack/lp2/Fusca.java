/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mack.lp2;

/**
 *
 * @author 31782299
 */
public class Fusca extends Automovel {
      @Override
    public void executaComando(int comando) {
        System.out.println("FUSCA ["+comando+"]");
    }
    
    public String toString(){
        return "sou um Fusca";
    }
    
}
