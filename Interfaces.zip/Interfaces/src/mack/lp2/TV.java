/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mack.lp2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author p017416
 */
public abstract class TV extends Operacao implements Controlavel {
    
    protected List<Operacao> comandos;
    
    public TV(){
        
        this.comandos = new ArrayList<>();
        this.comandos.add(new Operacao(1 ," Ligar "));
        
        
    }
    
    
    
}
