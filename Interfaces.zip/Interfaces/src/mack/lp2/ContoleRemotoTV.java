/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mack.lp2;

/**
 *
 * @author p017416
 */
public class ContoleRemotoTV extends ControleRemoto{

    @Override
    public void ligar() {
        System.out.println("Ligando uma TV");
    }

    @Override
    public void desligar() {
        System.out.println("Desligando uma TV");
    }

    @Override
    public void executarOperacao(int operacao) {
        System.out.println("Executando a operacao ["+operacao+"] em uma TV - "+this.equipamento);
        this.equipamento.executaComando(operacao);
    }
    
}
