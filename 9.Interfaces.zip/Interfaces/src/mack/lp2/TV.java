/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mack.lp2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author p017416
 */
public abstract class TV implements Controlavel{


    protected List<Operacao> operacoesPermitida;
    public TV(){
        this.operacoesPermitida = new ArrayList<Operacao>();
        this.operacoesPermitida.add(new Operacao(1,"Trocar Resolucao de tela"));
        this.operacoesPermitida.add(new Operacao(2,"Acionar Funcao Smart"));
        this.operacoesPermitida.add(new Operacao(3,"Acionar Funcao Futebol"));
        this.operacoesPermitida.add(new Operacao(4,"Re-channel"));
    }
    
    protected boolean verificaOperacao(Operacao oper){
        for (Operacao operacao : operacoesPermitida) {
            if(operacao.equals(oper))
                return true;
        }
        return false;
    }
    
    
    public List<Operacao> getOperacoesPermitida() {
        return operacoesPermitida;
    }
}
