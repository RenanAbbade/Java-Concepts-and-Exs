/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mack.lp2;

import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author p017416
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        TV minhaTV = new TVLG();
        ControleRemoto controleTV = new ContoleRemotoTV();
        controleTV.adicionarEquipamento(minhaTV);
        
        Operacao oper1 = new Operacao(1, "operacao 1");
        Operacao oper32 = new Operacao(32, "ligar Parabrisa");
        
        controleTV.executarOperacao(oper1);
        controleTV.executarOperacao(oper32);
        */
        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);
        
        boolean Control = true;
        while (Control == true){
            
            
            
            System.out.println("Que tipo de equipamento deseja operar? "
                    + "\n 1.TV "
                    + "\n 2.Carro "
                    + "\n 3.Sair ");
            int opc = sc.nextInt();
            while(opc != 1 && opc != 2 && opc != 3){ //Validação
                System.out.println("Digite corretamente! \n" +
                        "Que tipo de equipamento deseja operar? "
                    + "\n 1.TV "
                    + "\n 2.Carro "
                    + "\n 3.Sair ");
                opc = sc.nextInt();
            }
            if (opc == 1){ //TV
                
                ControleRemoto controleTV = new ContoleRemotoTV();
                
                System.out.println("Escolha: \n"
                        + "1.LG \n"
                        + "2.Philips \n");
                int escolhaTV = sc.nextInt();
                
                if (escolhaTV == 1){
                    
                    TV minhaTV = new TVLG();
                    controleTV.adicionarEquipamento(minhaTV);
                     
                }else if( escolhaTV == 2){
                    
                   TV minhaTV = new TVPhilips();
                   controleTV.adicionarEquipamento(minhaTV);
                    
                }
            
                System.out.print("Escolha uma operação para o seu equipamento TV realizar: \n"+
                "1. Trocar Resolucao de tela \n"+
                "2. Acionar Funcao Smart \n"+
                "3. Acionar Funcao Futebol \n"+
                "4.Re-channel \n");
                
                int opcOp = sc.nextInt();
               
                switch(opcOp){
                    case 1:
                        Operacao oper1 = new Operacao(1, "Trocar Resolucao de tela");
                        controleTV.executarOperacao(oper1);
                    break;
                    case 2: 
                        Operacao oper2 = new Operacao(2, "Acionar Funcao Smart");
                        controleTV.executarOperacao(oper2);
                    break;
                    case 3: 
                        Operacao oper3 = new Operacao(3, "Acionar Funcao Futebol");
                        controleTV.executarOperacao(oper3);
                    break;
                    case 4: 
                        Operacao oper4 = new Operacao(4, "Re-channel");
                        controleTV.executarOperacao(oper4);
                    break;
                        
                }
        
            } else if (opc ==2 ){ //CARRO
                ControleRemoto ControleCarro = new ControleRemotoCarro();
                System.out.println("Escolha: \n"
                        + "1.Ferrari \n"
                        + "2.Fusca \n");
                int escolhaCarro = sc.nextInt();
                
                if (escolhaCarro == 1){
                    
                    Automovel meuCarro = new Ferrari();
                    ControleCarro.adicionarEquipamento(meuCarro);
                     
                }else if( escolhaCarro == 2){
                    
                    Automovel meuCarro = new Fusca();
                    ControleCarro.adicionarEquipamento(meuCarro);
                    
                }
                
                 System.out.print("Escolha uma operação para o seu equipamento AUTOMOVEL realizar: \n"+
                "1. Trocar marcha \n"+
                "2. Freiar \n"+
                "3. Acelerar \n"+
                "4. TURBO \n");
                
                int opcOp = sc.nextInt();
               
                switch(opcOp){
                    case 1:
                        Operacao oper1 = new Operacao(1, "Trocar marcha");
                        ControleCarro.executarOperacao(oper1);
                    break;
                    case 2: 
                        Operacao oper2 = new Operacao(2, "Freiar");
                        ControleCarro.executarOperacao(oper2);
                    break;
                    case 3: 
                        Operacao oper3 = new Operacao(3, "Acelerar");
                        ControleCarro.executarOperacao(oper3);
                    break;
                    case 4: 
                        Operacao oper4 = new Operacao(4, "TURBO");
                        ControleCarro.executarOperacao(oper4);
                    break;
                        
                }
        
                
                //Ação
            }else if(opc == 3){
                Control = false;
            }
        }
        
        
        
    }

}
    


