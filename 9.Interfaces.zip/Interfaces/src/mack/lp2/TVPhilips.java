/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mack.lp2;

/**
 *
 * @author Renan
 */
public class TVPhilips extends TV{

    TVPhilips() {
       super();
    }

    @Override
    public void executaComando(Operacao oper) {
        if(super.verificaOperacao(oper))
            System.out.println("TV PHILIPS Executando comando ["+oper+"]");
        else
            System.out.println("Operacao Nao permitida para a TV");
    }
    
    @Override
    public String toString(){
        return "sou uma TV PHILIPS";
    }
    
}
