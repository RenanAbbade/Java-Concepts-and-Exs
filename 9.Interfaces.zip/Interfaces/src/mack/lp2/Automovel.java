/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mack.lp2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Renan
 */
public abstract class Automovel implements Controlavel {
    protected List<Operacao> operacoesPermitida;
    public Automovel(){
        this.operacoesPermitida = new ArrayList<Operacao>();
        this.operacoesPermitida.add(new Operacao(1,"Trocar marcha"));
        this.operacoesPermitida.add(new Operacao(2,"Freiar"));
        this.operacoesPermitida.add(new Operacao(3,"Acelerar"));
        this.operacoesPermitida.add(new Operacao(4,"Parar"));
    }
    
    protected boolean verificaOperacao(Operacao oper){
        for (Operacao operacao : operacoesPermitida) {
            if(operacao.equals(oper))
                return true;
        }
        return false;
    }

    @Override
    public void executaComando(Operacao oper) {
        
    }

    public List<Operacao> getOperacoesPermitida() {
        return operacoesPermitida;
    }
    
    
    
}
