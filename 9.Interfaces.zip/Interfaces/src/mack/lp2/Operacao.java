/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mack.lp2;

/**
 *
 * @author 1146355
 */
public class Operacao {

    private int id;
    private String descricao;
    
    public Operacao(int id, String descricao){
        this.descricao=descricao;
        this.id=id;
    }
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the descricao
     */
    public String getDescricao() {
        return descricao;
    }

    /**
     * @param descricao the descricao to set
     */
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    @Override
    public String toString(){
        return "Operacao ["+this.id+"] - "+this.descricao;
    }
    
    @Override
    public boolean equals(Object obj){
        return ( this.id == ((Operacao)obj).getId() );
    }
}
